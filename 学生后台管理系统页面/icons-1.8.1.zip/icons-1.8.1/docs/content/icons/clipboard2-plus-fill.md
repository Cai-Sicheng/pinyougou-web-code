---
title: Clipboard2 plus fill
categories:
  - Real world
tags:
  - copy
  - paste
---
