---
title: Bricks
categories:
  - Real world
tags:
  - wall
  - firewall
---
