---
title: Badge 8k
categories:
  - Badges
tags:
  - 4k
  - display
  - resolution
  - retina
---
